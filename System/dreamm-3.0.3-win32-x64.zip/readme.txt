DREAMM 3.0 readme

Thank you for checking out DREAMM.

This file contains a summary of what's new since the previous release.
For full documentation see https://aarongiles.com/dreamm/docs/v30

Report any issues or questions to dreamm@aarongiles.com

DREAMM is free, but if you like it, you can buy me a beer over at https://ko-fi.com/aaronsgiles


DREAMM 3.0.3 Changelog
======================
* Fixed Escape from Monkey Island, broken when Amazon version support was added
* Improved detection of alternate versions when add-ons/upgrades detected
* Fixed MacOS version number in resource bundle


DREAMM 3.0.2 Changelog
======================
* Added support for Amazon versions of Indy Crusade, Indy Fate, Loom, The Dig, EfMI
* Fixed Rebel Assault 1.7 installation (requires reinstall since I was missing a file)
* Fixed X-Wing/TIE CD Collector's editions when running from GOG/Steam releases
* Fixed juddery scrolling in Super Star Wars prototype
* Fixed launching Rebel Assault variants in standalone mode
* Fixed POV hats in Windows games
* Improved joystick remapping in the presence of asymmetric axes
* If you have no joystick, games will now see no joystick present
* Improved MacOS behavior when switching in/out of full screen
* Fixed occasional crash during user interface animations
* Fixed occasional crashes when encountering corrupt or unexpected image files


DREAMM 3.0.1 Changelog
======================
* Much improved Steam and GOG game compatibility
* Fixed crash/performance instability in 3D renderer on some systems
* Fixed crash if exiting while a menu was active in Windows games
* Fixed crash upgrading some games from the command line
* Added stricter checks in a couple of spots where other crashes have been reported
* Improved responsiveness of cancel when verifying


New Games and Variants added since 2.1.x
========================================
* New Lucasfilm DOS games supported:
   - PHM Pegasus (1988)
   - Battlehawks 1942 (1988)
   - Strike Fleet (1989)
   - Pipe Dream (1989)
   - Their Finest Hour: Battle of Britain (1989)
   - Indiana Jones and the Last Crusade: The Action Game (1989)
   - Night Shift (1990)
   - Secret Weapons of the Luftwaffe (1991)
   - Indiana Jones and the Fate of Atlantis: The Action Game (1992)
   - Master Blazer (1992)
* New Lucasfilm-related DOS games supported:
   - Indiana Jones And The Temple Of Doom (Mindscape/Atari Games/Tengen, 1989)
   - Super Star Wars prototype (never released)
   - Star Wars Chess (Software Toolworks, 1993)
* New LucasArts Windows games supported:
   - Pipe Dream (Lucasfilm/Microsoft, 1991)
   - Star Wars Chess (Software Toolworks, 1993)
   - Star Wars Screen Entertainment (LucasArts/Presage, 1994)
* Added support for expansion packs and upgraders, specifically for:
   - Their Finest Hour: Their Finest Missions
   - Secret Weapons of the Luftwaffe: 4 expansion packs
   - X-Wing: Imperial Pursuit and B-Wing expansion packs
   - TIE Fighter: Defender of the Empire expansion pack
   - Indiana Jones and the Last Crusade: CMS upgrade
   - Loom: Roland upgrade
   - Secret of Monkey Island: roland upgrade
   - Outlaws: Direct3D upgrade
* Added many, many new variants of existing games


New Emulation Features since 2.1.x
==================================
* Game deltas and configuration are now stored separately for each game version
   - This means that multiple versions won't interfere with each other
   - However, it means you will need to manually share save states or other info
* Rewrote video output path to use OpenGL with custom shaders
   - Use Alt-S/Cmd-S to toggle between basic scaling, epx smoothing, and CRT simulation
   - Basic scaling now uses a custom shader for higher quality results
   - epx smoothing is also now done on your GPU via a custom shader
   - CRT simulation is a new shader that models scanlines and shadow masks (works best at 1440p+)
   - If OpenGL support not available, falls back to old SDL way (but no CRT simulation)
* In-game volume controls are now more flexible and appear as their own popup
* Rewrote video BIOS implementation to match the particulars of each supported card
* Implemented more VGA features and added some more modes, up to 1280x1024
* Added accurate refresh timings for all video hardware
* Added "fixed mode" execution that provides more consistent behavior
   - Most early games (pre-Full Throttle) now run in fixed mode all the time
   - Later DOS games use fixed mode at startup (for timing loops), then switch to dynamic mode
   - Windows games continue to use previous dynamic mode
* Added keyboard scripting support so game installers are now automated
* Implemented many previously missing DOS and BIOS functions
   - This means you're less likely to hit an "unimplemented INT" error
   - Yes, you can now test your system in the Rebel Assault II launcher ;)
* Implemented a lot more of 16-bit Windows, so InstallShield installers work
* Added rudimentary DOS batch file support


New Frontend Features since 2.1.x
=================================
* General user interface changes:
   - Version is displayed in upper-right as link you can click to get the about box
   - UI text is rendered using FreeType at the output resolution
   - Text now auto-resizes in cases where it doesn't fit
   - Some small animations have been added to liven things up
* Main game select screen:
   - If you have lots of games you can now rotate through them via keyboard or mouse wheel
   - You can now type the first few characters of a name to jump there
   - Star Wars games are now sorted ignoring the "Star Wars:" prefix
* Configure and launch screen:
   - Scroll wheel now works to rotate between variants
   - The current game configuration options are shown, with a link to click to modify them
   - Interdependent options now work (e.g., resolution in Outlaws depends on graphics driver)
   - Configuration of MT32/GMIDI outputs now shown as a separate item
   - Advanced configuration options for CPU speed and joystick remapping
   - Split "Manage" into two tabs; added option to scan all variants of a game at once
* DREAMM tools/options:
   - New page combining tools and options in two tabs
   - Telemetry setting moved here from about box
   - Moved pause in background setting here and made it application global
   - New option to install sound fonts or MT-32 ROMs, plus show what's installed or view folder
* Adding/installing games:
   - Floppy/CD images and ZIP files nested within other containers are now detected and scanned
   - File dates & times are now preserved when installing
   - Created multi-disk install path to help installing from multiple physical disks
   - Added link to page with info on where to purchase games online
