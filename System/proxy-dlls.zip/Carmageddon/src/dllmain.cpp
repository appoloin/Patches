#include <windows.h>
#include "patch.h"

BOOL compare_qword(const void* buf1, const void* buf2);

LPVOID WINAPI fake_HeapAlloc(HANDLE hHeap, DWORD dwFlags, SIZE_T dwBytes)
{
    LPVOID result = HeapAlloc(hHeap, dwFlags, dwBytes);

    if (result)
    {
        DWORD op;
        VirtualProtect(result, dwBytes, PAGE_EXECUTE_READWRITE, &op);
    }

    return result;
}

void apply_patches()
{
    HMODULE game_exe = GetModuleHandle(NULL);

    if (game_exe && compare_qword((char*)game_exe + 0x00010004, "\xE0\xF6\xC4\x41\x0F\x85\x1D\x00"))
    {
        // This workaround makes sure the game works with DEP enabled
        // NOTE: It does not actually solve the main issue though - The executable bit will now just always be set
        HMODULE game_exe = GetModuleHandle(NULL);
        patch_call_nop((char*)game_exe + 0x000F7723, (char*)fake_HeapAlloc);
    }
}

BOOL WINAPI DllMain(HINSTANCE hinstDLL, DWORD fdwReason, LPVOID lpvReserved)
{
    switch(fdwReason)
    {
    case DLL_PROCESS_ATTACH:
        apply_patches();
        break;
    case DLL_PROCESS_DETACH:
        break;
    }
    return TRUE;
}

BOOL compare_qword(const void* buf1, const void* buf2)
{
    MEMORY_BASIC_INFORMATION mbi = { 0 };
    if (!VirtualQuery(buf1, &mbi, sizeof(mbi)))
        return FALSE;

    if ((mbi.State != MEM_COMMIT) || ((mbi.Protect & 0xff) == PAGE_NOACCESS) || (mbi.Protect & PAGE_GUARD))
        return FALSE;

    memset(&mbi, 0, sizeof(mbi));
    if (!VirtualQuery((char*)buf1 + 7, &mbi, sizeof(mbi)))
        return FALSE;

    if ((mbi.State != MEM_COMMIT) || ((mbi.Protect & 0xff) == PAGE_NOACCESS) || (mbi.Protect & PAGE_GUARD))
        return FALSE;

    return memcmp(buf1, buf2, 8) == 0;
}
