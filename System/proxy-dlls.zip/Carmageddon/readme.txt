1. Extract cnc-ddraw.zip into your game folder - https://github.com/FunkyFr3sh/cnc-ddraw/releases/latest/download/cnc-ddraw.zip
2. Extract the dsound.dll included in this .zip file into your game folder
