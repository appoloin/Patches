#include <windows.h>
#include "patch.h"

BOOL compare_qword(const void* buf1, const void* buf2);

void apply_patches()
{
    HMODULE game_exe = GetModuleHandle(NULL);

    if (game_exe && compare_qword((char*)game_exe + 0x00010000, "\x50\x89\x44\x24\x08\xE8\xD6\x24"))
    {
        // workaround for intro crash
        patch_clear_nop((char*)game_exe + 0x0006C1E2, (char*)game_exe + 0x0006C1E7);
        
        // Original GOG patches
        PATCH_SET((char*)game_exe + 0x0006BE14, "\x10");
        PATCH_SET((char*)game_exe + 0x0006C0DC, "\x90");
        PATCH_SET((char*)game_exe + 0x0006C0DE, "\x15\xCC");
        PATCH_SET((char*)game_exe + 0x0006C0E3, "\xC1\xEA\x09\x8B\x6E\x49\x8B\x4D\x08\xB8");
        PATCH_SET((char*)game_exe + 0x0006C0F1, "\x7A\x01\x42\xC1\xE2\x1E\x52\xFF\x70\x14\x51\xFF\x30\xB8\xE0\x01\x00");
        PATCH_SET((char*)game_exe + 0x0006C103, "\x29\xC8\xD1\xE8\x50\x53\x55");
    } // GOG
}

BOOL WINAPI DllMain(HINSTANCE hinstDLL, DWORD fdwReason, LPVOID lpvReserved)
{
    switch(fdwReason)
    {
    case DLL_PROCESS_ATTACH:
        apply_patches();
        break;
    case DLL_PROCESS_DETACH:
        break;
    }
    return TRUE;
}

BOOL compare_qword(const void* buf1, const void* buf2)
{
    MEMORY_BASIC_INFORMATION mbi = { 0 };
    if (!VirtualQuery(buf1, &mbi, sizeof(mbi)))
        return FALSE;

    if ((mbi.State != MEM_COMMIT) || ((mbi.Protect & 0xff) == PAGE_NOACCESS) || (mbi.Protect & PAGE_GUARD))
        return FALSE;

    memset(&mbi, 0, sizeof(mbi));
    if (!VirtualQuery((char*)buf1 + 7, &mbi, sizeof(mbi)))
        return FALSE;

    if ((mbi.State != MEM_COMMIT) || ((mbi.Protect & 0xff) == PAGE_NOACCESS) || (mbi.Protect & PAGE_GUARD))
        return FALSE;

    return memcmp(buf1, buf2, 8) == 0;
}
