// petool genproxy - https://github.com/FunkyFr3sh/petool

#include <windows.h>

FARPROC g_exports[19];
static INIT_ONCE g_exports_init_once;

static void exports_init()
{
    WCHAR path[MAX_PATH];
    if (!GetSystemDirectoryW(path, _countof(path)))
        return;

    if (wcscat_s(path, L"\\version.dll") != 0)
        return;

    HMODULE dll = LoadLibraryW(path);
    if (!dll)
        return;

    g_exports[0]   = GetProcAddress(dll, "GetFileVersionInfoA");
    g_exports[1]   = GetProcAddress(dll, "GetFileVersionInfoByHandle");
    g_exports[2]   = GetProcAddress(dll, "GetFileVersionInfoExA");
    g_exports[3]   = GetProcAddress(dll, "GetFileVersionInfoExW");
    g_exports[4]   = GetProcAddress(dll, "GetFileVersionInfoSizeA");
    g_exports[5]   = GetProcAddress(dll, "GetFileVersionInfoSizeExA");
    g_exports[6]   = GetProcAddress(dll, "GetFileVersionInfoSizeExW");
    g_exports[7]   = GetProcAddress(dll, "GetFileVersionInfoSizeW");
    g_exports[8]   = GetProcAddress(dll, "GetFileVersionInfoW");
    g_exports[9]   = GetProcAddress(dll, "VerFindFileA");
    g_exports[10]  = GetProcAddress(dll, "VerFindFileW");
    g_exports[11]  = GetProcAddress(dll, "VerInstallFileA");
    g_exports[12]  = GetProcAddress(dll, "VerInstallFileW");
    g_exports[13]  = GetProcAddress(dll, "VerLanguageNameA");
    g_exports[14]  = GetProcAddress(dll, "VerLanguageNameW");
    g_exports[15]  = GetProcAddress(dll, "VerQueryValueA");
    g_exports[16]  = GetProcAddress(dll, "VerQueryValueW");
    g_exports[17]  = GetProcAddress(dll, "VerQueryValueIndexA");
    g_exports[18]  = GetProcAddress(dll, "VerQueryValueIndexW");
}

#if defined(_MSC_VER)
#define ASM_JMP(a) __asm { jmp g_exports[a*4] }
#define NAKED __declspec(naked)
#define NOINLINE __declspec(noinline)
#else
#define ASM_JMP(a) __asm("jmp _g_exports[" #a "*4]")
#define NAKED __attribute__((naked))
#define NOINLINE __attribute__((noinline))
#endif

static NOINLINE void exports_init_once()
{
    BOOL pending;
    if (InitOnceBeginInitialize(&g_exports_init_once, 0, &pending, NULL) && pending)
    {
        exports_init();
        InitOnceComplete(&g_exports_init_once, 0, NULL);
    }
}

#define CREATE_EXPORT(a) \
    EXTERN_C NAKED void __export_##a() { \
        exports_init_once(); \
        ASM_JMP(a); \
    }

CREATE_EXPORT(0)
CREATE_EXPORT(1)
CREATE_EXPORT(2)
CREATE_EXPORT(3)
CREATE_EXPORT(4)
CREATE_EXPORT(5)
CREATE_EXPORT(6)
CREATE_EXPORT(7)
CREATE_EXPORT(8)
CREATE_EXPORT(9)
CREATE_EXPORT(10)
CREATE_EXPORT(11)
CREATE_EXPORT(12)
CREATE_EXPORT(13)
CREATE_EXPORT(14)
CREATE_EXPORT(15)
CREATE_EXPORT(16)
CREATE_EXPORT(17)
CREATE_EXPORT(18)
