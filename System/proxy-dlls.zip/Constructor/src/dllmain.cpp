#include <windows.h>
#include "patch.h"

BOOL compare_qword(const void* buf1, const void* buf2);

void apply_patches()
{
    HMODULE game_exe = GetModuleHandle(NULL);

    if (game_exe && compare_qword((char*)game_exe + 0x00010000, "\x54\x01\x00\x00\x7D\x2F\x89\xC8"))
    {
        /* Add workaround for waveOutGetPosition deadlock */
        patch_clear_nop((char*)game_exe + 0x0006CD70, (char*)game_exe + 0x0006CD70 + 2);
    }
}

BOOL WINAPI DllMain(HINSTANCE hinstDLL, DWORD fdwReason, LPVOID lpvReserved)
{
    switch(fdwReason)
    {
    case DLL_PROCESS_ATTACH:
        apply_patches();
        break;
    case DLL_PROCESS_DETACH:
        break;
    }
    return TRUE;
}

BOOL compare_qword(const void* buf1, const void* buf2)
{
    MEMORY_BASIC_INFORMATION mbi = { 0 };
    if (!VirtualQuery(buf1, &mbi, sizeof(mbi)))
        return FALSE;

    if ((mbi.State != MEM_COMMIT) || ((mbi.Protect & 0xff) == PAGE_NOACCESS) || (mbi.Protect & PAGE_GUARD))
        return FALSE;

    memset(&mbi, 0, sizeof(mbi));
    if (!VirtualQuery((char*)buf1 + 7, &mbi, sizeof(mbi)))
        return FALSE;

    if ((mbi.State != MEM_COMMIT) || ((mbi.Protect & 0xff) == PAGE_NOACCESS) || (mbi.Protect & PAGE_GUARD))
        return FALSE;

    return memcmp(buf1, buf2, 8) == 0;
}
