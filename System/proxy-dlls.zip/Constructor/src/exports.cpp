// petool genproxy - https://github.com/FunkyFr3sh/petool

#include <windows.h>

FARPROC g_exports[210];
static INIT_ONCE g_exports_init_once;

static void exports_init()
{
    WCHAR path[MAX_PATH];
    if (!GetSystemDirectoryW(path, _countof(path)))
        return;

    if (wcscat_s(path, L"\\winmm.dll") != 0)
        return;

    HMODULE dll = LoadLibraryW(path);
    if (!dll)
        return;

    g_exports[0]   = GetProcAddress(dll, MAKEINTRESOURCEA(2));
    g_exports[1]   = GetProcAddress(dll, "CloseDriver");
    g_exports[2]   = GetProcAddress(dll, "DefDriverProc");
    g_exports[3]   = GetProcAddress(dll, "DriverCallback");
    g_exports[4]   = GetProcAddress(dll, "DrvGetModuleHandle");
    g_exports[5]   = GetProcAddress(dll, "GetDriverModuleHandle");
    g_exports[6]   = GetProcAddress(dll, "MigrateAllDrivers");
    g_exports[7]   = GetProcAddress(dll, "MigrateSoundEvents");
    g_exports[8]   = GetProcAddress(dll, "NotifyCallbackData");
    g_exports[9]   = GetProcAddress(dll, "OpenDriver");
    g_exports[10]  = GetProcAddress(dll, "PlaySound");
    g_exports[11]  = GetProcAddress(dll, "PlaySoundA");
    g_exports[12]  = GetProcAddress(dll, "PlaySoundW");
    g_exports[13]  = GetProcAddress(dll, "SendDriverMessage");
    g_exports[14]  = GetProcAddress(dll, "WOW32DriverCallback");
    g_exports[15]  = GetProcAddress(dll, "WOW32ResolveMultiMediaHandle");
    g_exports[16]  = GetProcAddress(dll, "WOWAppExit");
    g_exports[17]  = GetProcAddress(dll, "WinmmLogoff");
    g_exports[18]  = GetProcAddress(dll, "WinmmLogon");
    g_exports[19]  = GetProcAddress(dll, "aux32Message");
    g_exports[20]  = GetProcAddress(dll, "auxGetDevCapsA");
    g_exports[21]  = GetProcAddress(dll, "auxGetDevCapsW");
    g_exports[22]  = GetProcAddress(dll, "auxGetNumDevs");
    g_exports[23]  = GetProcAddress(dll, "auxGetVolume");
    g_exports[24]  = GetProcAddress(dll, "auxOutMessage");
    g_exports[25]  = GetProcAddress(dll, "auxSetVolume");
    g_exports[26]  = GetProcAddress(dll, "gfxAddGfx");
    g_exports[27]  = GetProcAddress(dll, "gfxBatchChange");
    g_exports[28]  = GetProcAddress(dll, "gfxCreateGfxFactoriesList");
    g_exports[29]  = GetProcAddress(dll, "gfxCreateZoneFactoriesList");
    g_exports[30]  = GetProcAddress(dll, "gfxDestroyDeviceInterfaceList");
    g_exports[31]  = GetProcAddress(dll, "gfxEnumerateGfxs");
    g_exports[32]  = GetProcAddress(dll, "_gfxLogoff@0");
    g_exports[33]  = GetProcAddress(dll, "_gfxLogon@4");
    g_exports[34]  = GetProcAddress(dll, "gfxModifyGfx");
    g_exports[35]  = GetProcAddress(dll, "gfxOpenGfx");
    g_exports[36]  = GetProcAddress(dll, "gfxRemoveGfx");
    g_exports[37]  = GetProcAddress(dll, "joy32Message");
    g_exports[38]  = GetProcAddress(dll, "joyConfigChanged");
    g_exports[39]  = GetProcAddress(dll, "joyGetDevCapsA");
    g_exports[40]  = GetProcAddress(dll, "joyGetDevCapsW");
    g_exports[41]  = GetProcAddress(dll, "joyGetNumDevs");
    g_exports[42]  = GetProcAddress(dll, "joyGetPos");
    g_exports[43]  = GetProcAddress(dll, "joyGetPosEx");
    g_exports[44]  = GetProcAddress(dll, "joyGetThreshold");
    g_exports[45]  = GetProcAddress(dll, "joyReleaseCapture");
    g_exports[46]  = GetProcAddress(dll, "joySetCapture");
    g_exports[47]  = GetProcAddress(dll, "joySetThreshold");
    g_exports[48]  = GetProcAddress(dll, "mci32Message");
    g_exports[49]  = GetProcAddress(dll, "mciDriverNotify");
    g_exports[50]  = GetProcAddress(dll, "mciDriverYield");
    g_exports[51]  = GetProcAddress(dll, "mciExecute");
    g_exports[52]  = GetProcAddress(dll, "mciFreeCommandResource");
    g_exports[53]  = GetProcAddress(dll, "mciGetCreatorTask");
    g_exports[54]  = GetProcAddress(dll, "mciGetDeviceIDA");
    g_exports[55]  = GetProcAddress(dll, "mciGetDeviceIDFromElementIDA");
    g_exports[56]  = GetProcAddress(dll, "mciGetDeviceIDFromElementIDW");
    g_exports[57]  = GetProcAddress(dll, "mciGetDeviceIDW");
    g_exports[58]  = GetProcAddress(dll, "mciGetDriverData");
    g_exports[59]  = GetProcAddress(dll, "mciGetErrorStringA");
    g_exports[60]  = GetProcAddress(dll, "mciGetErrorStringW");
    g_exports[61]  = GetProcAddress(dll, "mciGetYieldProc");
    g_exports[62]  = GetProcAddress(dll, "mciLoadCommandResource");
    g_exports[63]  = GetProcAddress(dll, "mciSendCommandA");
    g_exports[64]  = GetProcAddress(dll, "mciSendCommandW");
    g_exports[65]  = GetProcAddress(dll, "mciSendStringA");
    g_exports[66]  = GetProcAddress(dll, "mciSendStringW");
    g_exports[67]  = GetProcAddress(dll, "mciSetDriverData");
    g_exports[68]  = GetProcAddress(dll, "mciSetYieldProc");
    g_exports[69]  = GetProcAddress(dll, "mid32Message");
    g_exports[70]  = GetProcAddress(dll, "midiConnect");
    g_exports[71]  = GetProcAddress(dll, "midiDisconnect");
    g_exports[72]  = GetProcAddress(dll, "midiInAddBuffer");
    g_exports[73]  = GetProcAddress(dll, "midiInClose");
    g_exports[74]  = GetProcAddress(dll, "midiInGetDevCapsA");
    g_exports[75]  = GetProcAddress(dll, "midiInGetDevCapsW");
    g_exports[76]  = GetProcAddress(dll, "midiInGetErrorTextA");
    g_exports[77]  = GetProcAddress(dll, "midiInGetErrorTextW");
    g_exports[78]  = GetProcAddress(dll, "midiInGetID");
    g_exports[79]  = GetProcAddress(dll, "midiInGetNumDevs");
    g_exports[80]  = GetProcAddress(dll, "midiInMessage");
    g_exports[81]  = GetProcAddress(dll, "midiInOpen");
    g_exports[82]  = GetProcAddress(dll, "midiInPrepareHeader");
    g_exports[83]  = GetProcAddress(dll, "midiInReset");
    g_exports[84]  = GetProcAddress(dll, "midiInStart");
    g_exports[85]  = GetProcAddress(dll, "midiInStop");
    g_exports[86]  = GetProcAddress(dll, "midiInUnprepareHeader");
    g_exports[87]  = GetProcAddress(dll, "midiOutCacheDrumPatches");
    g_exports[88]  = GetProcAddress(dll, "midiOutCachePatches");
    g_exports[89]  = GetProcAddress(dll, "midiOutClose");
    g_exports[90]  = GetProcAddress(dll, "midiOutGetDevCapsA");
    g_exports[91]  = GetProcAddress(dll, "midiOutGetDevCapsW");
    g_exports[92]  = GetProcAddress(dll, "midiOutGetErrorTextA");
    g_exports[93]  = GetProcAddress(dll, "midiOutGetErrorTextW");
    g_exports[94]  = GetProcAddress(dll, "midiOutGetID");
    g_exports[95]  = GetProcAddress(dll, "midiOutGetNumDevs");
    g_exports[96]  = GetProcAddress(dll, "midiOutGetVolume");
    g_exports[97]  = GetProcAddress(dll, "midiOutLongMsg");
    g_exports[98]  = GetProcAddress(dll, "midiOutMessage");
    g_exports[99]  = GetProcAddress(dll, "midiOutOpen");
    g_exports[100] = GetProcAddress(dll, "midiOutPrepareHeader");
    g_exports[101] = GetProcAddress(dll, "midiOutReset");
    g_exports[102] = GetProcAddress(dll, "midiOutSetVolume");
    g_exports[103] = GetProcAddress(dll, "midiOutShortMsg");
    g_exports[104] = GetProcAddress(dll, "midiOutUnprepareHeader");
    g_exports[105] = GetProcAddress(dll, "midiStreamClose");
    g_exports[106] = GetProcAddress(dll, "midiStreamOpen");
    g_exports[107] = GetProcAddress(dll, "midiStreamOut");
    g_exports[108] = GetProcAddress(dll, "midiStreamPause");
    g_exports[109] = GetProcAddress(dll, "midiStreamPosition");
    g_exports[110] = GetProcAddress(dll, "midiStreamProperty");
    g_exports[111] = GetProcAddress(dll, "midiStreamRestart");
    g_exports[112] = GetProcAddress(dll, "midiStreamStop");
    g_exports[113] = GetProcAddress(dll, "mixerClose");
    g_exports[114] = GetProcAddress(dll, "mixerGetControlDetailsA");
    g_exports[115] = GetProcAddress(dll, "mixerGetControlDetailsW");
    g_exports[116] = GetProcAddress(dll, "mixerGetDevCapsA");
    g_exports[117] = GetProcAddress(dll, "mixerGetDevCapsW");
    g_exports[118] = GetProcAddress(dll, "mixerGetID");
    g_exports[119] = GetProcAddress(dll, "mixerGetLineControlsA");
    g_exports[120] = GetProcAddress(dll, "mixerGetLineControlsW");
    g_exports[121] = GetProcAddress(dll, "mixerGetLineInfoA");
    g_exports[122] = GetProcAddress(dll, "mixerGetLineInfoW");
    g_exports[123] = GetProcAddress(dll, "mixerGetNumDevs");
    g_exports[124] = GetProcAddress(dll, "mixerMessage");
    g_exports[125] = GetProcAddress(dll, "mixerOpen");
    g_exports[126] = GetProcAddress(dll, "mixerSetControlDetails");
    g_exports[127] = GetProcAddress(dll, "mmDrvInstall");
    g_exports[128] = GetProcAddress(dll, "mmGetCurrentTask");
    g_exports[129] = GetProcAddress(dll, "mmTaskBlock");
    g_exports[130] = GetProcAddress(dll, "mmTaskCreate");
    g_exports[131] = GetProcAddress(dll, "mmTaskSignal");
    g_exports[132] = GetProcAddress(dll, "mmTaskYield");
    g_exports[133] = GetProcAddress(dll, "mmioAdvance");
    g_exports[134] = GetProcAddress(dll, "mmioAscend");
    g_exports[135] = GetProcAddress(dll, "mmioClose");
    g_exports[136] = GetProcAddress(dll, "mmioCreateChunk");
    g_exports[137] = GetProcAddress(dll, "mmioDescend");
    g_exports[138] = GetProcAddress(dll, "mmioFlush");
    g_exports[139] = GetProcAddress(dll, "mmioGetInfo");
    g_exports[140] = GetProcAddress(dll, "mmioInstallIOProcA");
    g_exports[141] = GetProcAddress(dll, "mmioInstallIOProcW");
    g_exports[142] = GetProcAddress(dll, "mmioOpenA");
    g_exports[143] = GetProcAddress(dll, "mmioOpenW");
    g_exports[144] = GetProcAddress(dll, "mmioRead");
    g_exports[145] = GetProcAddress(dll, "mmioRenameA");
    g_exports[146] = GetProcAddress(dll, "mmioRenameW");
    g_exports[147] = GetProcAddress(dll, "mmioSeek");
    g_exports[148] = GetProcAddress(dll, "mmioSendMessage");
    g_exports[149] = GetProcAddress(dll, "mmioSetBuffer");
    g_exports[150] = GetProcAddress(dll, "mmioSetInfo");
    g_exports[151] = GetProcAddress(dll, "mmioStringToFOURCCA");
    g_exports[152] = GetProcAddress(dll, "mmioStringToFOURCCW");
    g_exports[153] = GetProcAddress(dll, "mmioWrite");
    g_exports[154] = GetProcAddress(dll, "mmsystemGetVersion");
    g_exports[155] = GetProcAddress(dll, "mod32Message");
    g_exports[156] = GetProcAddress(dll, "mxd32Message");
    g_exports[157] = GetProcAddress(dll, "sndPlaySoundA");
    g_exports[158] = GetProcAddress(dll, "sndPlaySoundW");
    g_exports[159] = GetProcAddress(dll, "tid32Message");
    g_exports[160] = GetProcAddress(dll, "timeBeginPeriod");
    g_exports[161] = GetProcAddress(dll, "timeEndPeriod");
    g_exports[162] = GetProcAddress(dll, "timeGetDevCaps");
    g_exports[163] = GetProcAddress(dll, "timeGetSystemTime");
    g_exports[164] = GetProcAddress(dll, "timeGetTime");
    g_exports[165] = GetProcAddress(dll, "timeKillEvent");
    g_exports[166] = GetProcAddress(dll, "timeSetEvent");
    g_exports[167] = GetProcAddress(dll, "waveInAddBuffer");
    g_exports[168] = GetProcAddress(dll, "waveInClose");
    g_exports[169] = GetProcAddress(dll, "waveInGetDevCapsA");
    g_exports[170] = GetProcAddress(dll, "waveInGetDevCapsW");
    g_exports[171] = GetProcAddress(dll, "waveInGetErrorTextA");
    g_exports[172] = GetProcAddress(dll, "waveInGetErrorTextW");
    g_exports[173] = GetProcAddress(dll, "waveInGetID");
    g_exports[174] = GetProcAddress(dll, "waveInGetNumDevs");
    g_exports[175] = GetProcAddress(dll, "waveInGetPosition");
    g_exports[176] = GetProcAddress(dll, "waveInMessage");
    g_exports[177] = GetProcAddress(dll, "waveInOpen");
    g_exports[178] = GetProcAddress(dll, "waveInPrepareHeader");
    g_exports[179] = GetProcAddress(dll, "waveInReset");
    g_exports[180] = GetProcAddress(dll, "waveInStart");
    g_exports[181] = GetProcAddress(dll, "waveInStop");
    g_exports[182] = GetProcAddress(dll, "waveInUnprepareHeader");
    g_exports[183] = GetProcAddress(dll, "waveOutBreakLoop");
    g_exports[184] = GetProcAddress(dll, "waveOutClose");
    g_exports[185] = GetProcAddress(dll, "waveOutGetDevCapsA");
    g_exports[186] = GetProcAddress(dll, "waveOutGetDevCapsW");
    g_exports[187] = GetProcAddress(dll, "waveOutGetErrorTextA");
    g_exports[188] = GetProcAddress(dll, "waveOutGetErrorTextW");
    g_exports[189] = GetProcAddress(dll, "waveOutGetID");
    g_exports[190] = GetProcAddress(dll, "waveOutGetNumDevs");
    g_exports[191] = GetProcAddress(dll, "waveOutGetPitch");
    g_exports[192] = GetProcAddress(dll, "waveOutGetPlaybackRate");
    g_exports[193] = GetProcAddress(dll, "waveOutGetPosition");
    g_exports[194] = GetProcAddress(dll, "waveOutGetVolume");
    g_exports[195] = GetProcAddress(dll, "waveOutMessage");
    g_exports[196] = GetProcAddress(dll, "waveOutOpen");
    g_exports[197] = GetProcAddress(dll, "waveOutPause");
    g_exports[198] = GetProcAddress(dll, "waveOutPrepareHeader");
    g_exports[199] = GetProcAddress(dll, "waveOutReset");
    g_exports[200] = GetProcAddress(dll, "waveOutRestart");
    g_exports[201] = GetProcAddress(dll, "waveOutSetPitch");
    g_exports[202] = GetProcAddress(dll, "waveOutSetPlaybackRate");
    g_exports[203] = GetProcAddress(dll, "waveOutSetVolume");
    g_exports[204] = GetProcAddress(dll, "waveOutUnprepareHeader");
    g_exports[205] = GetProcAddress(dll, "waveOutWrite");
    g_exports[206] = GetProcAddress(dll, "wid32Message");
    g_exports[207] = GetProcAddress(dll, "winmmDbgOut");
    g_exports[208] = GetProcAddress(dll, "winmmSetDebugLevel");
    g_exports[209] = GetProcAddress(dll, "wod32Message");
}

#if defined(_MSC_VER)
#define ASM_JMP(a) __asm { jmp g_exports[a*4] }
#define NAKED __declspec(naked)
#define NOINLINE __declspec(noinline)
#else
#define ASM_JMP(a) __asm("jmp _g_exports[" #a "*4]")
#define NAKED __attribute__((naked))
#define NOINLINE __attribute__((noinline))
#endif

static NOINLINE void exports_init_once()
{
    BOOL pending;
    if (InitOnceBeginInitialize(&g_exports_init_once, 0, &pending, NULL) && pending)
    {
        exports_init();
        InitOnceComplete(&g_exports_init_once, 0, NULL);
    }
}

#define CREATE_EXPORT(a) \
    EXTERN_C NAKED void __export_##a() { \
        exports_init_once(); \
        ASM_JMP(a); \
    }

CREATE_EXPORT(0)
CREATE_EXPORT(1)
CREATE_EXPORT(2)
CREATE_EXPORT(3)
CREATE_EXPORT(4)
CREATE_EXPORT(5)
CREATE_EXPORT(6)
CREATE_EXPORT(7)
CREATE_EXPORT(8)
CREATE_EXPORT(9)
CREATE_EXPORT(10)
CREATE_EXPORT(11)
CREATE_EXPORT(12)
CREATE_EXPORT(13)
CREATE_EXPORT(14)
CREATE_EXPORT(15)
CREATE_EXPORT(16)
CREATE_EXPORT(17)
CREATE_EXPORT(18)
CREATE_EXPORT(19)
CREATE_EXPORT(20)
CREATE_EXPORT(21)
CREATE_EXPORT(22)
CREATE_EXPORT(23)
CREATE_EXPORT(24)
CREATE_EXPORT(25)
CREATE_EXPORT(26)
CREATE_EXPORT(27)
CREATE_EXPORT(28)
CREATE_EXPORT(29)
CREATE_EXPORT(30)
CREATE_EXPORT(31)
CREATE_EXPORT(32)
CREATE_EXPORT(33)
CREATE_EXPORT(34)
CREATE_EXPORT(35)
CREATE_EXPORT(36)
CREATE_EXPORT(37)
CREATE_EXPORT(38)
CREATE_EXPORT(39)
CREATE_EXPORT(40)
CREATE_EXPORT(41)
CREATE_EXPORT(42)
CREATE_EXPORT(43)
CREATE_EXPORT(44)
CREATE_EXPORT(45)
CREATE_EXPORT(46)
CREATE_EXPORT(47)
CREATE_EXPORT(48)
CREATE_EXPORT(49)
CREATE_EXPORT(50)
CREATE_EXPORT(51)
CREATE_EXPORT(52)
CREATE_EXPORT(53)
CREATE_EXPORT(54)
CREATE_EXPORT(55)
CREATE_EXPORT(56)
CREATE_EXPORT(57)
CREATE_EXPORT(58)
CREATE_EXPORT(59)
CREATE_EXPORT(60)
CREATE_EXPORT(61)
CREATE_EXPORT(62)
CREATE_EXPORT(63)
CREATE_EXPORT(64)
CREATE_EXPORT(65)
CREATE_EXPORT(66)
CREATE_EXPORT(67)
CREATE_EXPORT(68)
CREATE_EXPORT(69)
CREATE_EXPORT(70)
CREATE_EXPORT(71)
CREATE_EXPORT(72)
CREATE_EXPORT(73)
CREATE_EXPORT(74)
CREATE_EXPORT(75)
CREATE_EXPORT(76)
CREATE_EXPORT(77)
CREATE_EXPORT(78)
CREATE_EXPORT(79)
CREATE_EXPORT(80)
CREATE_EXPORT(81)
CREATE_EXPORT(82)
CREATE_EXPORT(83)
CREATE_EXPORT(84)
CREATE_EXPORT(85)
CREATE_EXPORT(86)
CREATE_EXPORT(87)
CREATE_EXPORT(88)
CREATE_EXPORT(89)
CREATE_EXPORT(90)
CREATE_EXPORT(91)
CREATE_EXPORT(92)
CREATE_EXPORT(93)
CREATE_EXPORT(94)
CREATE_EXPORT(95)
CREATE_EXPORT(96)
CREATE_EXPORT(97)
CREATE_EXPORT(98)
CREATE_EXPORT(99)
CREATE_EXPORT(100)
CREATE_EXPORT(101)
CREATE_EXPORT(102)
CREATE_EXPORT(103)
CREATE_EXPORT(104)
CREATE_EXPORT(105)
CREATE_EXPORT(106)
CREATE_EXPORT(107)
CREATE_EXPORT(108)
CREATE_EXPORT(109)
CREATE_EXPORT(110)
CREATE_EXPORT(111)
CREATE_EXPORT(112)
CREATE_EXPORT(113)
CREATE_EXPORT(114)
CREATE_EXPORT(115)
CREATE_EXPORT(116)
CREATE_EXPORT(117)
CREATE_EXPORT(118)
CREATE_EXPORT(119)
CREATE_EXPORT(120)
CREATE_EXPORT(121)
CREATE_EXPORT(122)
CREATE_EXPORT(123)
CREATE_EXPORT(124)
CREATE_EXPORT(125)
CREATE_EXPORT(126)
CREATE_EXPORT(127)
CREATE_EXPORT(128)
CREATE_EXPORT(129)
CREATE_EXPORT(130)
CREATE_EXPORT(131)
CREATE_EXPORT(132)
CREATE_EXPORT(133)
CREATE_EXPORT(134)
CREATE_EXPORT(135)
CREATE_EXPORT(136)
CREATE_EXPORT(137)
CREATE_EXPORT(138)
CREATE_EXPORT(139)
CREATE_EXPORT(140)
CREATE_EXPORT(141)
CREATE_EXPORT(142)
CREATE_EXPORT(143)
CREATE_EXPORT(144)
CREATE_EXPORT(145)
CREATE_EXPORT(146)
CREATE_EXPORT(147)
CREATE_EXPORT(148)
CREATE_EXPORT(149)
CREATE_EXPORT(150)
CREATE_EXPORT(151)
CREATE_EXPORT(152)
CREATE_EXPORT(153)
CREATE_EXPORT(154)
CREATE_EXPORT(155)
CREATE_EXPORT(156)
CREATE_EXPORT(157)
CREATE_EXPORT(158)
CREATE_EXPORT(159)
CREATE_EXPORT(160)
CREATE_EXPORT(161)
CREATE_EXPORT(162)
CREATE_EXPORT(163)
CREATE_EXPORT(164)
CREATE_EXPORT(165)
CREATE_EXPORT(166)
CREATE_EXPORT(167)
CREATE_EXPORT(168)
CREATE_EXPORT(169)
CREATE_EXPORT(170)
CREATE_EXPORT(171)
CREATE_EXPORT(172)
CREATE_EXPORT(173)
CREATE_EXPORT(174)
CREATE_EXPORT(175)
CREATE_EXPORT(176)
CREATE_EXPORT(177)
CREATE_EXPORT(178)
CREATE_EXPORT(179)
CREATE_EXPORT(180)
CREATE_EXPORT(181)
CREATE_EXPORT(182)
CREATE_EXPORT(183)
CREATE_EXPORT(184)
CREATE_EXPORT(185)
CREATE_EXPORT(186)
CREATE_EXPORT(187)
CREATE_EXPORT(188)
CREATE_EXPORT(189)
CREATE_EXPORT(190)
CREATE_EXPORT(191)
CREATE_EXPORT(192)
CREATE_EXPORT(193)
CREATE_EXPORT(194)
CREATE_EXPORT(195)
CREATE_EXPORT(196)
CREATE_EXPORT(197)
CREATE_EXPORT(198)
CREATE_EXPORT(199)
CREATE_EXPORT(200)
CREATE_EXPORT(201)
CREATE_EXPORT(202)
CREATE_EXPORT(203)
CREATE_EXPORT(204)
CREATE_EXPORT(205)
CREATE_EXPORT(206)
CREATE_EXPORT(207)
CREATE_EXPORT(208)
CREATE_EXPORT(209)
