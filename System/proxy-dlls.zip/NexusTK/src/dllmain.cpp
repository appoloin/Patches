#include <windows.h>
#include <stdio.h>
#include "patch.h"

typedef struct HOOKLISTDATA { char function_name[32]; PROC new_function; PROC* function; HMODULE mod; } HOOKLISTDATA;
typedef struct HOOKLIST { char module_name[32]; HOOKLISTDATA data[34]; } HOOKLIST;

void hook_patch_iat(HMODULE hmod, BOOL unhook, const char* module_name, const char* function_name, PROC new_function);

HANDLE WINAPI fake_CreateMutexA(LPSECURITY_ATTRIBUTES lpMutexAttributes, BOOL bInitialOwner, LPCSTR lpName)
{
    char r[64];
    _snprintf(r, sizeof(r)-1, "%lu", GetTickCount());
    
    return CreateMutexA(lpMutexAttributes, bInitialOwner, r);
}

BOOL WINAPI DllMain(HINSTANCE hinstDLL, DWORD fdwReason, LPVOID lpvReserved)
{
    switch(fdwReason)
    {
    case DLL_PROCESS_ATTACH:
        hook_patch_iat(GetModuleHandle(NULL), FALSE, "Kernel32.dll", "CreateMutexA", (PROC)fake_CreateMutexA);
        break;
    case DLL_PROCESS_DETACH:
        break;
    }
    return TRUE;
}

void hook_patch_iat_list(HMODULE hmod, BOOL unhook, HOOKLIST* hooks)
{
    if (!hmod || !hooks)
        return;

    PIMAGE_DOS_HEADER dos_header = (PIMAGE_DOS_HEADER)hmod;
    if (dos_header->e_magic != IMAGE_DOS_SIGNATURE)
        return;

    PIMAGE_NT_HEADERS nt_headers = (PIMAGE_NT_HEADERS)((DWORD)hmod + (DWORD)dos_header->e_lfanew);
    if (nt_headers->Signature != IMAGE_NT_SIGNATURE)
        return;

    DWORD import_desc_rva = nt_headers->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT].VirtualAddress;
    DWORD import_desc_size = nt_headers->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT].Size;

    if (import_desc_rva == 0 || import_desc_size == 0)
        return;

    PIMAGE_IMPORT_DESCRIPTOR import_desc = (PIMAGE_IMPORT_DESCRIPTOR)((DWORD)hmod + import_desc_rva);

    while (import_desc->FirstThunk)
    {
        if (!import_desc->Name)
        {
            import_desc++;
            continue;
        }

        for (int i = 0; hooks[i].module_name[0]; i++)
        {
            char* imp_module_name = (char*)((DWORD)hmod + import_desc->Name);

            if (_stricmp(imp_module_name, hooks[i].module_name) == 0)
            {
                HMODULE cur_mod = GetModuleHandleA(hooks[i].module_name);

                PIMAGE_THUNK_DATA first_thunk = (PIMAGE_THUNK_DATA)((DWORD)hmod + import_desc->FirstThunk);

                while (first_thunk->u1.Function)
                {
                    for (int x = 0; hooks[i].data[x].function_name[0]; x++)
                    {
                        DWORD org_function = (DWORD)GetProcAddress(cur_mod, hooks[i].data[x].function_name);

                        if (!hooks[i].data[x].new_function || !org_function)
                            continue;

                        if (unhook)
                        {
                            if (first_thunk->u1.Function == (DWORD)hooks[i].data[x].new_function)
                            {
                                DWORD op;

                                if (VirtualProtect(
                                    &first_thunk->u1.Function,
                                    sizeof(DWORD),
                                    PAGE_READWRITE,
                                    &op))
                                {
                                    first_thunk->u1.Function = org_function;

                                    VirtualProtect(&first_thunk->u1.Function, sizeof(DWORD), op, &op);
                                }

                                break;
                            }
                        }
                        else
                        {
                            if (first_thunk->u1.Function == org_function)
                            {
                                DWORD op;

                                if (VirtualProtect(
                                    &first_thunk->u1.Function,
                                    sizeof(DWORD),
                                    PAGE_READWRITE,
                                    &op))
                                {
                                    first_thunk->u1.Function = (DWORD)hooks[i].data[x].new_function;

                                    VirtualProtect(&first_thunk->u1.Function, sizeof(DWORD), op, &op);
                                }

                                break;
                            }
                        }
                    }

                    first_thunk++;
                }

                break;
            }
        }

        import_desc++;
    }
}

void hook_patch_iat(HMODULE hmod, BOOL unhook, const char* module_name, const char* function_name, PROC new_function)
{
    HOOKLIST hooks[2];
    memset(&hooks, 0, sizeof(hooks));

    hooks[0].data[0].new_function = new_function;

    strncpy(hooks[0].module_name, module_name, sizeof(hooks[0].module_name) - 1);
    strncpy(hooks[0].data[0].function_name, function_name, sizeof(hooks[0].data[0].function_name) - 1);

    hook_patch_iat_list(hmod, unhook, (HOOKLIST*)&hooks);
}
