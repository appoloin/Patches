#include <windows.h>
#include "patch.h"

BOOL compare_qword(const void* buf1, const void* buf2);

void apply_patches()
{
    HMODULE game_exe = GetModuleHandle(NULL);

    if (game_exe && compare_qword((char*)game_exe + 0x00010000, "\x8B\x44\x24\x04\x89\x41\x04\xC2"))
    {
        /* Do not disable renderer */
        patch_clear_nop((char*)game_exe + 0x0000AF46, (char*)game_exe + 0x0000AF46 + 5);
        patch_clear_nop((char*)game_exe + 0x001E13AC, (char*)game_exe + 0x001E13AC + 5);
        patch_clear_nop((char*)game_exe + 0x001E1845, (char*)game_exe + 0x001E1845 + 5);
        
        /* Disable Alt+Tab detection logic (Make sure game is always active) */
        patch_clear_nop((char*)game_exe + 0x001E181F, (char*)game_exe + 0x001E1860);
        
        /* Pretend that we are never minimized */
        patch_sjmp((char*)game_exe + 0x001E1399, (char*)game_exe + 0x001E13C0);
        
        /* Pretend that we are never minimized */
        patch_clear_nop((char*)game_exe + 0x0010F910, (char*)game_exe + 0x0010F924);
        
        /* Do not minimize/deactiate renderer */
        patch_clear_nop((char*)game_exe + 0x00113070, (char*)game_exe + 0x00113087);
        
        /* Disable WM_ACTIVATEAPP logic (Make sure game is always active) */
        patch_clear_nop((char*)game_exe + 0x000095A2, (char*)game_exe + 0x000095E5);
        
    } /* retail */

    else if (game_exe && compare_qword((char*)game_exe + 0x00010000, "\x8B\x06\x6A\x0F\x6A\x01\x8B\xCE"))
    {
        /* Do not disable renderer */
        patch_clear_nop((char*)game_exe + 0x0000AF26, (char*)game_exe + 0x0000AF26 + 5);
        patch_clear_nop((char*)game_exe + 0x001E039C, (char*)game_exe + 0x001E039C + 5);
        patch_clear_nop((char*)game_exe + 0x001E0835, (char*)game_exe + 0x001E0835 + 5);
        
        /* Disable Alt+Tab detection logic (Make sure game is always active) */
        patch_clear_nop((char*)game_exe + 0x001E080F, (char*)game_exe + 0x001E0850);
        
        /* Pretend that we are never minimized */
        patch_sjmp((char*)game_exe + 0x001E0389, (char*)game_exe + 0x001E03B0);
        
        /* Pretend that we are never minimized */
        patch_clear_nop((char*)game_exe + 0x0010EFB0, (char*)game_exe + 0x0010EFC4);
        
        /* Do not minimize/deactiate renderer */
        patch_clear_nop((char*)game_exe + 0x00112710, (char*)game_exe + 0x00112727);
        
        /* Disable WM_ACTIVATEAPP logic (Make sure game is always active) */
        patch_clear_nop((char*)game_exe + 0x00009582, (char*)game_exe + 0x000095C5);
        
    } /* GoG */
}

BOOL WINAPI DllMain(HINSTANCE hinstDLL, DWORD fdwReason, LPVOID lpvReserved)
{
    switch(fdwReason)
    {
    case DLL_PROCESS_ATTACH:
        apply_patches();
        break;
    case DLL_PROCESS_DETACH:
        break;
    }
    return TRUE;
}

BOOL compare_qword(const void* buf1, const void* buf2)
{
    MEMORY_BASIC_INFORMATION mbi = { 0 };
    if (!VirtualQuery(buf1, &mbi, sizeof(mbi)))
        return FALSE;

    if ((mbi.State != MEM_COMMIT) || ((mbi.Protect & 0xff) == PAGE_NOACCESS) || (mbi.Protect & PAGE_GUARD))
        return FALSE;

    memset(&mbi, 0, sizeof(mbi));
    if (!VirtualQuery((char*)buf1 + 7, &mbi, sizeof(mbi)))
        return FALSE;

    if ((mbi.State != MEM_COMMIT) || ((mbi.Protect & 0xff) == PAGE_NOACCESS) || (mbi.Protect & PAGE_GUARD))
        return FALSE;

    return memcmp(buf1, buf2, 8) == 0;
}
