#include <windows.h>
#include <ddraw.h>

BOOL WINAPI DllMain(HINSTANCE hinstDLL, DWORD fdwReason, LPVOID lpvReserved)
{
    if (fdwReason == 11223344) /* Force ddraw.dll import */
    {
        DirectDrawEnumerateA(0, 0);
    }
    return TRUE;
}
