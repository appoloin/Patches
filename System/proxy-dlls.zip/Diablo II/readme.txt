1. Extract cnc-ddraw.zip into your game folder - https://github.com/FunkyFr3sh/cnc-ddraw/releases/latest/download/cnc-ddraw.zip
2. Extract the winmm.dll included in this .zip file into your game folder

Note: This patch is for single player only, do not try to connect to battle.net with custom patches (you might get banned)

Download links for classic Diablo 2 installers:
https://us.forums.blizzard.com/en/blizzard/t/main-thread-failed-network-error-for-diablo-ii-lod-set-up-files/4475/13
