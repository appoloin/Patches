#include <windows.h>
#include "patch.h"

typedef struct HOOKLISTDATA { char function_name[32]; PROC new_function; PROC* function; HMODULE mod; } HOOKLISTDATA;
typedef struct HOOKLIST { char module_name[32]; HOOKLISTDATA data[34]; } HOOKLIST;

BOOL compare_qword(const void* buf1, const void* buf2);
void hook_patch_iat(HMODULE hmod, BOOL unhook, const char* module_name, const char* function_name, PROC new_function);
void revert_patches();

HBITMAP g_bmp;

HDC __stdcall fake_CreateDCA(LPCSTR pwszDriver, LPCSTR pwszDevice, LPCSTR pszPort, const DEVMODEA* pdm)
{
    if (!g_bmp && strcmp(pwszDriver, "DISPLAY") == 0 && !pwszDevice && !pszPort && !pdm)
    {
        HDC hdc = CreateCompatibleDC(NULL);
        g_bmp = CreateCompatibleBitmap(hdc, 8, 16);

        return hdc;
    }

    return CreateDCA(pwszDriver, pwszDevice, pszPort, pdm);
}

HBITMAP __stdcall fake_CreateBitmap(int nWidth, int nHeight, UINT nPlanes, UINT nBitCount, const VOID* lpBits)
{
    if (g_bmp && !lpBits && nBitCount == 8 && nPlanes == 1 && nHeight == 16 && nWidth == 8)
    {
        revert_patches();
        return g_bmp;
    }

    return CreateBitmap(nWidth, nHeight, nPlanes, nBitCount, lpBits);
}

void apply_patches()
{
    HMODULE game_exe = GetModuleHandle(NULL);
    
    if (game_exe && compare_qword((char*)game_exe + 0x83EF, "\xFF\x24\x85\x38\x84\x40\x00\xC6"))
    {
        /* Force DirectDraw renderer */
        patch_setbyte((BYTE*)game_exe + 0x83E3, 0xEB);
    } /* D2 LOD 1.13c */
    
    else if (game_exe && compare_qword((char*)game_exe + 0x7BC4, "\xFF\x24\x85\x0C\x7C\x40\x00\xC6"))
    {
        /* Force DirectDraw renderer */
        patch_setbyte((BYTE*)game_exe + 0x7BB8, 0xEB);
    } /* D2 LOD 1.13d */
    
    else if (game_exe && compare_qword((char*)game_exe + 0x00010000, "\x00\x5F\x5E\x5D\x5B\x33\xCC\xE8"))
    {
        /* Force DirectDraw renderer */
        patch_setbyte((BYTE*)game_exe + 0x1F16, 1);
    } /* D2 LOD 1.14a */

    else if (game_exe && compare_qword((char*)game_exe + 0x00010000, "\x99\x99\x99\x19\x72\x40\x8B\xCE"))
    {
        /* Force DirectDraw renderer */
        patch_setbyte((BYTE*)game_exe + 0x1E3E, 1);
    } /* D2 1.14b */

    else if (game_exe && compare_qword((char*)game_exe + 0x00010000, "\x06\x3C\x65\x5F\x74\x04\x3C\x45"))
    {
        /* Force DirectDraw renderer */
        patch_setbyte((BYTE*)game_exe + 0x1F16, 1);
    } /* D2 LOD 1.14b / 1.14c */

    else if (game_exe && compare_qword((char*)game_exe + 0x00010000, "\x45\xF4\x64\xA3\x00\x00\x00\x00"))
    {
        /* Force DirectDraw renderer */
        patch_setbyte((BYTE*)game_exe + 0x63D9, 1);
    } /* D2 1.14d */
    
    else if (game_exe && compare_qword((char*)game_exe + 0x00010008, "\xE8\xC3\xFE\xFF\xFF\x33\xC0\x68"))
    {
        /* Force DirectDraw renderer */
        patch_setbyte((BYTE*)game_exe + 0x65A5, 1);
    } /* D2 LOD 1.14d */

    /* Force DirectDraw renderer (pre 1.14 versions) */
    HKEY hkey;
    LONG status =
        RegCreateKeyExA(
            HKEY_CURRENT_USER,
            "SOFTWARE\\Blizzard Entertainment\\Diablo II\\VideoConfig",
            0,
            NULL,
            REG_OPTION_NON_VOLATILE,
            KEY_WRITE | KEY_QUERY_VALUE,
            NULL,
            &hkey,
            NULL);

    if (status == ERROR_SUCCESS)
    {
        DWORD v = 0;
        RegSetValueExA(hkey, "Render", 0, REG_DWORD, (const BYTE*)&v, sizeof(v));
        
        /* Remove all choices from D2VidTst.exe except DirectDraw */
        v = 0;
        RegSetValueExA(hkey, "Recommend1", 0, REG_DWORD, (const BYTE*)&v, sizeof(v));
        RegSetValueExA(hkey, "Recommend2", 0, REG_DWORD, (const BYTE*)&v, sizeof(v));
        RegSetValueExA(hkey, "Recommend3", 0, REG_DWORD, (const BYTE*)&v, sizeof(v));
        RegSetValueExA(hkey, "Recommend4", 0, REG_DWORD, (const BYTE*)&v, sizeof(v));
        RegCloseKey(hkey);
    }

    /* Fix slow game start (Scrolling letters in top left of the screen) */
    /* pre 1.14 versions */
    hook_patch_iat(GetModuleHandle("D2DDraw.dll"), FALSE, "gdi32.dll", "CreateDCA", (PROC)fake_CreateDCA);
    hook_patch_iat(GetModuleHandle("D2DDraw.dll"), FALSE, "gdi32.dll", "CreateBitmap", (PROC)fake_CreateBitmap);

    /* all 1.14 versions */
    hook_patch_iat(GetModuleHandle(NULL), FALSE, "gdi32.dll", "CreateDCA", (PROC)fake_CreateDCA);
    hook_patch_iat(GetModuleHandle(NULL), FALSE, "gdi32.dll", "CreateBitmap", (PROC)fake_CreateBitmap);
}

void revert_patches()
{
    HMODULE game_exe = GetModuleHandle(NULL);

    if (game_exe && compare_qword((char*)game_exe + 0x83EF, "\xFF\x24\x85\x38\x84\x40\x00\xC6"))
    {
        patch_setbyte((BYTE*)game_exe + 0x83E3, 0x75);
    } /* D2 LOD 1.13c */

    else if (game_exe && compare_qword((char*)game_exe + 0x7BC4, "\xFF\x24\x85\x0C\x7C\x40\x00\xC6"))
    {
        patch_setbyte((BYTE*)game_exe + 0x7BB8, 0x75);
    } /* D2 LOD 1.13d */

    else if (game_exe && compare_qword((char*)game_exe + 0x00010000, "\x00\x5F\x5E\x5D\x5B\x33\xCC\xE8"))
    {
        patch_setbyte((BYTE*)game_exe + 0x1F16, 0);
    } /* D2 LOD 1.14a */

    else if (game_exe && compare_qword((char*)game_exe + 0x00010000, "\x99\x99\x99\x19\x72\x40\x8B\xCE"))
    {
        patch_setbyte((BYTE*)game_exe + 0x1E3E, 0);
    } /* D2 1.14b */

    else if (game_exe && compare_qword((char*)game_exe + 0x00010000, "\x06\x3C\x65\x5F\x74\x04\x3C\x45"))
    {
        patch_setbyte((BYTE*)game_exe + 0x1F16, 0);
    } /* D2 LOD 1.14b / 1.14c */

    else if (game_exe && compare_qword((char*)game_exe + 0x00010000, "\x45\xF4\x64\xA3\x00\x00\x00\x00"))
    {
        patch_setbyte((BYTE*)game_exe + 0x63D9, 0);
    } /* D2 1.14d */
    
    else if (game_exe && compare_qword((char*)game_exe + 0x00010008, "\xE8\xC3\xFE\xFF\xFF\x33\xC0\x68"))
    {
        patch_setbyte((BYTE*)game_exe + 0x65A5, 0);
    } /* D2 LOD 1.14d */

    /* pre 1.14 versions */
    hook_patch_iat(GetModuleHandle("D2DDraw.dll"), TRUE, "gdi32.dll", "CreateDCA", (PROC)fake_CreateDCA);
    hook_patch_iat(GetModuleHandle("D2DDraw.dll"), TRUE, "gdi32.dll", "CreateBitmap", (PROC)fake_CreateBitmap);

    /* all 1.14 versions */
    hook_patch_iat(GetModuleHandle(NULL), TRUE, "gdi32.dll", "CreateDCA", (PROC)fake_CreateDCA);
    hook_patch_iat(GetModuleHandle(NULL), TRUE, "gdi32.dll", "CreateBitmap", (PROC)fake_CreateBitmap);
}

BOOL WINAPI DllMain(HINSTANCE hinstDLL, DWORD fdwReason, LPVOID lpvReserved)
{
    switch(fdwReason)
    {
    case DLL_PROCESS_ATTACH:
        apply_patches();
        break;
    case DLL_PROCESS_DETACH:
        break;
    }
    return TRUE;
}

BOOL compare_qword(const void* buf1, const void* buf2)
{
    MEMORY_BASIC_INFORMATION mbi = { 0 };
    if (!VirtualQuery(buf1, &mbi, sizeof(mbi)))
        return FALSE;

    if ((mbi.State != MEM_COMMIT) || ((mbi.Protect & 0xff) == PAGE_NOACCESS) || (mbi.Protect & PAGE_GUARD))
        return FALSE;

    memset(&mbi, 0, sizeof(mbi));
    if (!VirtualQuery((char*)buf1 + 7, &mbi, sizeof(mbi)))
        return FALSE;

    if ((mbi.State != MEM_COMMIT) || ((mbi.Protect & 0xff) == PAGE_NOACCESS) || (mbi.Protect & PAGE_GUARD))
        return FALSE;

    return memcmp(buf1, buf2, 8) == 0;
}

void hook_patch_iat_list(HMODULE hmod, BOOL unhook, HOOKLIST* hooks)
{
    if (!hmod || !hooks)
        return;

    PIMAGE_DOS_HEADER dos_header = (PIMAGE_DOS_HEADER)hmod;
    if (dos_header->e_magic != IMAGE_DOS_SIGNATURE)
        return;

    PIMAGE_NT_HEADERS nt_headers = (PIMAGE_NT_HEADERS)((DWORD)hmod + (DWORD)dos_header->e_lfanew);
    if (nt_headers->Signature != IMAGE_NT_SIGNATURE)
        return;

    DWORD import_desc_rva = nt_headers->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT].VirtualAddress;
    DWORD import_desc_size = nt_headers->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT].Size;

    if (import_desc_rva == 0 || import_desc_size == 0)
        return;

    PIMAGE_IMPORT_DESCRIPTOR import_desc = (PIMAGE_IMPORT_DESCRIPTOR)((DWORD)hmod + import_desc_rva);

    while (import_desc->FirstThunk)
    {
        if (!import_desc->Name)
        {
            import_desc++;
            continue;
        }

        for (int i = 0; hooks[i].module_name[0]; i++)
        {
            char* imp_module_name = (char*)((DWORD)hmod + import_desc->Name);

            if (_stricmp(imp_module_name, hooks[i].module_name) == 0)
            {
                HMODULE cur_mod = GetModuleHandleA(hooks[i].module_name);

                PIMAGE_THUNK_DATA first_thunk = (PIMAGE_THUNK_DATA)((DWORD)hmod + import_desc->FirstThunk);

                while (first_thunk->u1.Function)
                {
                    for (int x = 0; hooks[i].data[x].function_name[0]; x++)
                    {
                        DWORD org_function = (DWORD)GetProcAddress(cur_mod, hooks[i].data[x].function_name);

                        if (!hooks[i].data[x].new_function || !org_function)
                            continue;

                        if (unhook)
                        {
                            if (first_thunk->u1.Function == (DWORD)hooks[i].data[x].new_function)
                            {
                                DWORD op;

                                if (VirtualProtect(
                                    &first_thunk->u1.Function,
                                    sizeof(DWORD),
                                    PAGE_READWRITE,
                                    &op))
                                {
                                    first_thunk->u1.Function = org_function;

                                    VirtualProtect(&first_thunk->u1.Function, sizeof(DWORD), op, &op);
                                }

                                break;
                            }
                        }
                        else
                        {
                            if (first_thunk->u1.Function == org_function)
                            {
                                DWORD op;

                                if (VirtualProtect(
                                    &first_thunk->u1.Function,
                                    sizeof(DWORD),
                                    PAGE_READWRITE,
                                    &op))
                                {
                                    first_thunk->u1.Function = (DWORD)hooks[i].data[x].new_function;

                                    VirtualProtect(&first_thunk->u1.Function, sizeof(DWORD), op, &op);
                                }

                                break;
                            }
                        }
                    }

                    first_thunk++;
                }

                break;
            }
        }

        import_desc++;
    }
}

void hook_patch_iat(HMODULE hmod, BOOL unhook, const char* module_name, const char* function_name, PROC new_function)
{
    HOOKLIST hooks[2];
    memset(&hooks, 0, sizeof(hooks));

    hooks[0].data[0].new_function = new_function;

    strncpy(hooks[0].module_name, module_name, sizeof(hooks[0].module_name) - 1);
    strncpy(hooks[0].data[0].function_name, function_name, sizeof(hooks[0].data[0].function_name) - 1);

    hook_patch_iat_list(hmod, unhook, (HOOKLIST*)&hooks);
}
