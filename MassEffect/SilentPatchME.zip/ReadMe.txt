SilentPatch for Mass Effect
Build 2
Last update - 07.11.2020
Co-developed with Rafael Rivers


DESCRIPTION

	Mass Effect is a popular franchise of sci-fi roleplaying games. The first game was initially
	released by BioWare in late 2007 on Xbox 360 exclusively as a part of a publishing deal with Microsoft.
	A few months later in mid-2008, the game received PC port developed by Demiurge Studios.
	It was a decent port with no obvious flaws, that is until 2011 when AMD released their new Bulldozer-based CPUs.
	When playing the game on PCs with modern AMD processors, two areas in the game (Noveria and Ilos) show severe graphical artifacts.

	SilentPatch diagnoses those issues and provides a definite fix, bringing complete visual parity between Intel and AMD CPUs.

	Featured fixes:

	* Fixed an issue causing black blobs to appear with contemporary AMD CPUs.
	  WARNING: AMD FX and Bulldozer chips are still affected. We are investigating the issue.


INSTALLATION

	Easy as pie. You only need to extract the archive contents to your Mass Effect directory.

	Instructions on locating your game directory can be found here:
	https://cookieplmonster.github.io/setup-instructions/


SUPPORTERS

	@Sarkies_Proxy
	@Twogirlsonekevin
	Calinou
	CriminaL277
	deSSy2724
	dreamfall
	Iman Shahani
	Lagahan
	retrozone.co
	Vetle Ledaal


CONTACT

	zdanio95@gmail.com - e-mail
	Silent#1222 - Discord

Subscribe to my YouTube channel for more footage from my mods!
https://www.youtube.com/user/CookiePLMonster

Follow my Twitter account to be up to all my mods updates!
https://twitter.com/__silent_

Also take a look at my blog, featuring modding and programming related articles and more!
https://cookieplmonster.github.io/
