#pragma once

#include "common/ICriticalSection.h"

extern ICriticalSection	g_loadGameLock;
