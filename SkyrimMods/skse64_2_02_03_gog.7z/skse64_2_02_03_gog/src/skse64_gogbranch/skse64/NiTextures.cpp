#include "skse64/NiTextures.h"

RelocAddr<_CreateSourceTexture> CreateSourceTexture(0x00CA32B0);
RelocAddr<_LoadTexture> LoadTexture(0x013B54A0);
