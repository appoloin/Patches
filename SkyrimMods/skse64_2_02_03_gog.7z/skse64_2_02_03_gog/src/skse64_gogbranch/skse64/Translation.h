#pragma once

class BSScaleformTranslator;

namespace Translation
{
	void ImportTranslationFiles(BSScaleformTranslator * translator);
}
