Widescreen fix for Prince of Persia: Warrior Within ver 1.0.0.188
Created by nemesis2000 <nemesis2000@yandex.ru>
Downloaded from http://ps2wide.net/pc.html

Installation Instructions
=========================================================================

1. Unpack [password: pop2]
2. Run upx.bat (for GOG version of the game)
3. Edit pop2.ini
4. Enjoy


Additional Information
=========================================================================

1. Supported exe size: 5�533�696 bytes


References
=========================================================================

1. UPX: the Ultimate Packer for eXecutables <http://upx.sourceforge.net/>