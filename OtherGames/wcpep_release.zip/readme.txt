----------------------------------------------------------------------------------
             Wing Commander Prophecy - Enhancement Pack - Release 1
----------------------------------------------------------------------------------

The enhancement pack is collection of patches made by myself which correct and 
improve the game in several ways. This is still an experimental version, mostly 
meant as a functionality preview, put together to celebrate the 8th birthday
of the WC CIC.

To install this package, simply unzip the contents into the prophecy directory.
The following patches are included:

- Video Skip Patch : corrects some video and comms issues on fast computers.
- High-res Patch : allows using for high resolutions in the game (install.exe)
- Multiplayer Patch: Release 1 of the Multiplayer patch has minor enhancements
  compared to the test release, plus scoreboard support. It is still largely
  experimental, so keep this in mind while you play. Feedback is appreciated!

After unzipping the file, you can run prophecy.exe as usual to run the game
or multiplayer.exe to run the game in the experimental multiplayer mode. Be sure
to unblock port 5555, TCP/IP, from your firewall.

Note that in order to enable the highres patch, you need to run install.exe . 
This installer will need to find in the patch\ directory the files data.tre, 
gf.tre gf2.tre and gf3.tre, so copy them from the various CDs. Direct3D mode
can handle pretty much any resolution supported by your hardware. 


-- Plans for the future:

My work will definitely be focused on the Multiplayer patch, adding MP support
to mission scripts and AI. This will allow for the creation of more complex
scenarios. More news on this soon!

--
Mario "HCl" Brito