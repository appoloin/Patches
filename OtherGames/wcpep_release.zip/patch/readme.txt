Copy into this directory the following files from the CDs:

- data.tre (cd1)
- gf.tre (cd1)
- gf2.tre (cd2)
- gf3.tre (cd3)

The install program needs to find these files here.

Mario Brito
(HCl)
