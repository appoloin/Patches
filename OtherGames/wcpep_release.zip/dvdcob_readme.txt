This patch allows Prophecy to play the high-res VOB files made available by the CIC.
Keep in mind that this is still experimental code, so please report any problems you
encounter.

To install this patch:

- Install the WCP high-res patch
- Replace the existing wcphr.dll with this one.
- Install mpeg2 and ac3 codecs in your system. Mpeg2dec and ac3filter are recomended.
- Create a MOVIE\ folder on your Prophecy installation and place the VOB files there.

If something goes wrong, there are a couple of things you can try:

- If you are using a Glide wrapper, try switching to Direct3D mode.

- Under Direct3D mode, experiment playing the movies with subtitles on and off. The 
  patch uses slightly different code for each option, so it is possible one of those
  might work better on your system.


Mario "HCl" Brito
mbrito@dei.uc.pt