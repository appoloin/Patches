/////////////////////////////////////////////////////////////
// A basic script to test Vector Math.
/////////////////////////////////////////////////////////////

void add(float a, float b)
{
	system.print("{} + {} = {}", a, b, a + b);
}

void stringTest(string str)
{
	system.print("string = {}", str);
}

void float2Add(float2 a, float2 b)
{
	system.print("{} + {} = {}", a, b, a + b);
}