===============================================================================

   Metal Gear Solid Integral (PC) Launcher 1.3
   created by bmn
   https://mgs.w00ty.com/
   https://www.youtube.com/@gogobmn

   Saves collection and a lot of testing by dlimes13:
   https://www.speedrun.com/user/dlimes13

   Additional testing for 1.3 by the Lime City community


   In this file...
   * Installation
   * Main Game Launcher
   * Patch Installer
   * Save Manager
   * Program Updates
   * Clearing Launcher Data

===============================================================================

   Installation:
   * This launcher has been tested with the GOG and oxide-NL versions of
     MGS Integral. Have one of them installed already.
   * Extract all files in the MGSI Launcher zip to the MGSI install directory
     * GOG Galaxy:  %ProgramFiles(x86)%\GOG Galaxy\Games\Metal Gear Solid
     * GOG non-DRM: C:\GOG Games\Metal Gear Solid
     * oxide-NL:    %ProgramFiles(x86)%\MetalGearSolid

===============================================================================

   Main Game Launcher
   ==================

   Basic Usage:
   * Open MGSILauncher.exe to launch the configurator.
     * You should not open the launcher (or the game itself) as administrator,
       this could cause problems.
   * "Launch Game" will open the game with the settings displayed in the
     launcher at the time.
   * "Save Config" will save your current config, and load it when you
     open MGSIL in the future.

   Priority:
   * MGSI defaults to Normal CPU priority. Changing this may make the game
     or other programs run faster or more smoothly.
   * Real Time priority is not provided as an option, as it requires
     Admin privileges and can cause system instability.

   Core Affinity:
   * Changing the "affinity" (which CPU cores are used to run the game) can
     help avoid crashes while playing. What works well is specific to every
     system.
   * Use Ctrl+Click to select multiple cores, and Shift+Click to select
     a range.
   * Most people experience good results using Cores 0+1.
   * GOG users will sometimes experience hanging during Gray Fox's monologue
     with Rex. Using more cores seems to help avoid this.
   * All existing releases default to Core 0 only.
   * See this link for more information:
     https://metalgearspeedrunners.com/wiki/doku.php?id=mgs1_faq#pc_troubleshooting

   Launch Settings:
   * "Mode" offers the standard Exclusive Fullscreen and Windowed modes. It
     also offers a custom Windowed Fullscreen, which places the window in a
     fullscreen-like position (depending on chosen aspect ratio).
     * On GOG, there is instead a button to open the official display configurator.
   * "Size" (Windowed mode only) resizes the game window on launch.
     * "Inside" will set the size of the window so that the game itself
       is the size specified. "Outside" will make the whole window the
       specified size instead.
   * "Position" (Windowed mode only) moves the window to the desired position.
     * The position is in pixels relative to the top left corner of the game
       window and the top left corner of the desktop.
   * "Extra" sets the available command-line options for the game. Of note:
     * -cheatenable gives a few cheat functions:
       * F2 gives Snake maximum Life.
       * F4 gives unlimited ammo.
       * F5/F6 disables/enables a free camera controlled with the keyboard
         and mouse.
       * F7 restarts the current area, useful for practice.
       * F8-F12 toggles different graphics filters.
       * Shift+[weapon hotkey] (top row number keys) unlocks that weapon.
       * Shift+Esc unlocks all items.
     * -nocd disables the CD check that can sometimes cause issues on the
       oxide-NL release.
     * -pad2 to -pad9 (requires a patch, see the Patch Installer section below)
       have the game use a different gamepad to the default, if you have
       more than one connected.
       
   Save Game Profile:
   * "Apply profile on launch" will replace the game's current set of
     saves with the saves from a profile of your choice, every time the
     game launches.
     * Be aware that this will overwrite any existing saves!
   * You can edit your save profiles using the Save Game Manager (see
     below).

   Game Settings Backup:
   * MGSI stores user/graphics settings in mgs.cfg and mgsvideo.cfg.
     These files can become corrupted in various ways.
     * This occurs frequently on oxide-NL. We don't know whether this
       is also an issue on GOG.
   * "Backup Settings" will have MGSIL keep a copy of the current files.
     You must do this before the below options will work.
   * "Restore Settings" will restore the files to the game.
   * If "Always restore game setting files" is enabled, MGSIL will restore
     the files every time you launch the game.
     This will automatically reverse any file corruption that occurs.
     * Don't enable this until you're happy with your game settings!

   Clear Gamepad Binds:
   * In some cases you may want to clear all of the gamepad keybindings
     (e.g. when setting up controls to avoid being input read by Mantis).
   * Click the gamepad icon in the status bar, or type the cheat code UNBIND
     in the main window, to clear everything on the gamepad side of the
     current controller config.
   * If you have a settings backup already, you will need to save a new backup
     or make sure restore on launch is disabled.
   
   Game Shortcuts:
   * "Create Game Shortcut" opens a save prompt to create a shortcut.
     This shortcut will launch the game directly without having to go
     through the launcher.
   * The shortcut will apply the saved launcher config (not including
     the save game profile - see below) at the time you open the shortcut,
     so the settings don't need to be correct at the time you create the
     shortcut.
   * If you enable "Apply profile on launch" and choose a save game
     profile (it's not necessary to save the config afterwards), then
     click "Create Game Shortcut", the created shortcut will also apply
     that profile when it launches the game.
     * You can use this to create multiple shortcuts, one for each save
       game profile.
   * Hold Shift when opening a shortcut to open the launcher window instead.

   CD image mounting:
   * For some oxide-NL users on older versions, attempting to start a new game
     will trigger an "Insert Disc 1" prompt.
   * If you see this, try the "-nocd" option in the "Extra" dropdown in Launch
     Settings.
   * Or type the cheat code MOUNT in the configurator. This will mount an empty
     CD to the first available letter, and in some cases will cause the game to
     let you play.
   * In rare cases you may need to mount the CD more than once.
   

===============================================================================

   Patch Installer
   ===============

   * The patch installer lets you apply various modifications to the main game
     executable.
   * Click the musical note sign in the status bar to open the installer.
   * First click the Backup buttons to make a backup of the .exe/.dll files.
     * These backups will be used as the starting point whenever you click the
       Patch button.
   * Select which patches you want in the dropdown, then click the Patch button
     to apply them.
   * oxide-NL users may see a UAC prompt when unpacking the music or patching
     the exe, if those files are protected. The exe filesize will also
     increase, because this version is UPX packed and it needs to be unpacked
     to apply the patch.

   Available patches:
   * Music Patch
     * MGSI on PC is notorious for its low quality, badly-looped and often
     just plain incorrect music.
     * This patch brings the game closer to the PSX original.
     * You need to download and unpack the modified audio files first, using
       the buttons in the music patch section of the installer.
   * Weapon & Cheat Hotkeys Together
     * When the -cheatenable option is switched on, you're normally unable to
       use the standard weapon equip hotkeys, due to a programming oversight.
     * This patch makes weapon hotkeys work again in -cheatenable mode.
     * This is currently allowed in the Very Easy categories on Speedrun.com,
       and all of the single-disc categories, and is highly recommended.
   * Numpad Weapon Hotkeys
     * The PC version has a convenience function where you can press the keys
       1 to 0 on the number row (above the letters) to switch weapon.
     * This patch adds the same function to the keys on the number pad.
   * Native Diagonal D-Pad Controls
     * Normally you can only map the d-pad or analogue stick to the directions,
       not both, and d-pad controls don't work with diagonals.
     * This patch fixes diagonal d-pad inputs, without the need to use a custom
       mapping setup in a tool such as AntiMicro[X] or DS4Windows.
     * If you've created such a custom setup previously, you may need to revert
       the changes.
     * You must map the gamepad direction inputs to the d-pad in-game.
   * Native Analogue Controls
     * MGSI on PC does not support full 360-degree analogue controls, and
       limits you to 8-way controls (equivalent to the console d-pad controls)
       regardless of which controller you use.
     * This patch reactivates the analogue mode, giving you PSX-style analogue
       controls via the analogue stick.
     * You must map the gamepad direction inputs to the d-pad in-game.
     * Using both the Diagonal and Analogue patches together is recommended for
       a console-like experience, but they will still work on their own.
   * Disable Mouse Input
     * The mouse is a menace in MGSI.
     * This patch stops it from causing menus etc. to scroll.
   * Disable SW Mode Mouse Capture (GOG only)
     * The mouse is even more of a menace in GOG windowed mode.
     * This patch stops the game locking the mouse into the window.
     * It also makes the cursor visible, and lets you drag and drop the window.
     * This patch (by necessity) includes the Disable Mouse Input patch,
       so it makes no difference if you enable both.
     * You need to make a backup of ddraw.dll first, using the provided button.
   * Clearer Controller Options UI Text
     * This patch changes the wording of some parts of the user interface,
       primarily in the Controller Setup dialogue.
   * Select Gamepad in Extra Options
     * MGSI on PC only supports one connected gamepad, and will use a
       particular pad if more than one is connected.
     * This patch enables the "Use nth gamepad instead" options in the Extra
       Launch Options menu, which will have the game connect to the nth
       gamepad it finds.
     * You may need some trial and error to find the correct setting for a
       particular gamepad.
     * Only one gamepad option should be selected. If multiple options are
       selected, the one with the lowest number will be used.
   * Gamepad in Background
     * This patch allows you to use gamepad controls even when the game is
       unfocused (clicked away from).
     * Keyboard controls will not do anything when the game is unfocused.
   * Audio in Background
     * This patch plays the game audio even when the game is unfocused.
   * Fix Blank Save Bug
     * MGSI PC has a bug in the Load Game/Save Game menu that can happen when
       you have a certain number of saves. It causes some saves to disappear,
       and a blank save to appear instead.
     * This patch fixes the programming error that causes the bug to occur.


===============================================================================

   Save Manager
   ============

   * The Save Manager provides a set of premade saves for various situations,
     and lets you create profiles to easily replace your current set of saves.
   * The provided saves are aimed at speedrunners, so some of them won't be
     relevant for casual players.
   * If you want to edit the collection (e.g. to remove saves you don't want,
     or to add your own saves/categories), click the "Opens the Available
     Saves Folder" button at the bottom right.

   Usage:
   * Open MGSIL, and click the Save Manager button.
   * On first use, an Available Saves collection will be built in MGSIL's
     data store at %LocalAppData%\MGSILauncher\SavedGames. The window will
     take a few seconds to open while this happens.
     * You can edit this directory to change the organisation or add/remove
       available saves if you like.

   General layout:
   * Available saves are on the left.
   * Use the two combo boxes at the bottom-left to select a category.
     The saves for that category will appear in the list on the left.
   * On the right, you can select either your profiles, or a view of the saves
     currently available in-game.


   Profiles view
   -------------

   Adding saves to/removing saves from a profile:
   * Select save(s) in Available Saves using the mouse/keyboard and click the
     "+" button in the middle (or double click the save) to add them to the
     current profile.
   * Select saves in the list on the right, and click the Up/Down buttons
     to reorder them, or the wastebasket button to remove them from the profile.
   * Click the "Save" button to save the lists for all your profiles.

   Organising profiles:
   * Use the combo box near the bottom-middle to select a profile to work
     on.
   * Click the "+" button at the bottom and enter a name to add a new
     profile.
   * Click the wastebasket button to remove the currently-selected profile.

   Make a profile's saves available in-game:
   * Have the desired profile selected as the Current Profile.
   * Click the "Apply" button to replace the game's current set of saves
     with the saves from the current profile.


   Current Save Set view
   ---------------------

   Adding saves to/removing saves from the current save set:
   * Select save(s) in Available Saves and click the right arrow or double
     click the save to add them to the current save set.
   * Select saves in the list on the right, and click the Up/Down buttons
     to reorder them, or the wastebasket button in the middle to remove them
     from the profile.
   * Click the "Clear" button to clear the Current Save Set list.
   * Click the "Apply" button to apply any changes in-game.

   Organising custom Available Saves categories:
   * "Custom Saves" is an available primary Available Saves category.
   * After creating a secondary category here, you can store your own saves to
     use in profiles later, or to send to the current save set.
   * Click the "+" button at the bottom and enter a name to create a new
     secondary category for custom saves.
   * Click the wastebasket button at the bottom to remove the currently-
     selected custom category and all saves in it.

   Copying saves from the current save set to a custom category:
   * Make sure a custom Available Saves category is selected on the left.
   * Select save(s) in Current Save Set, and click the left arrow (or double
     click the save) to copy it to the custom category.
   * The copy process from right-to-left is done immediately; you don't have to
     click another button to apply it.
   * Click the wastebasket button in the middle to delete a custom save.

   Filename clash behaviours:
   * When using Profiles, the category names are added to the name of each save
     file. However, when using Current Save Set, category names are not added.
   * This means that, when moving saves to and from the current save set, you
     can have two files with the same name.
   * The two dropdown menus at the bottom-right decide what to do when this
     happens.
   * The left menu decides the behaviour when copying right-to-left.
     The right menu decides the behaviour when copying left-to-right.
   * Available options:
     * "Always rename new": Always asks for a new name for the save being
       moved, even if there is no clash.
     * "Rename new": Asks for a new name for the save being moved.
     * "Rename old": Asks for a new name for the clashing save that's already
       in the destination.
     * "Overwrite": Removes the clashing save that's already in the destination,
       and replaces it with the save being moved.
     * "Do nothing": Cancel moving the current save (and any other saves also
       selected after this one).


===============================================================================

   Program Updates
   ===============

   * Click the "?" sign in the status bar to open the about window.
   * The version number of the most recent launcher release is displayed.
   * Click "Download latest version" to download and install the latest release.
   * By default, the launcher checks online for updates once a day. You can
     disable this auto-check or increase the time between checks here.
   * Click "Check for updates now" to perform a check manually.
   * If the music pack or patch collection has been updated online, they will
     be downloaded automatically when checking for updates.
   * For minor patch updates, you can reinstall them without having to update
     the launcher. Otherwise, the patch installer will prompt you to update
     fully.

===============================================================================

   Clearing Launcher Data
   ======================

   There is currently no command to clear data stored by the launcher.
   You can access the data manually at the directory
   %LocalAppData%\MGSILauncher
   or by clicking the "Opens the launcher's data folder" button at the bottom
   of the main configurator window.
