SilentPatch for AquaNox
Build 2
Last update - 31.03.2020


DESCRIPTION

	SilentPatch for AquaNox, fixing widely reported mouse control issues.
	A bug present only in the first game (AquaNox 2 fixed it) would cause the game to drop mouse input
	frequently when mice or keyboard with high polling rate have been used. It's now been fixed
	the same way AquaNox 2 did.

	Featured fixes:

	* Fixed issues with stuttery/unresponsive mouse and keyboard input when using mice and/or keyboards with high
	  polling rate


INSTALLATION

	Easy as pie. You only need to extract archive contents to your AquaNox directory.


SUPPORTERS

	retrozone.co
	SkyNET
	TWIST_OF_HATE
	Vetle Ledaal


CONTACT

	zdanio95@gmail.com - e-mail
	Silent#1222 - Discord

Subscribe to my YouTube channel for more footage from my mods!
https://www.youtube.com/user/CookiePLMonster

Follow my Twitter account to be up to all my mods updates!
http://twitter.com/__silent_

Also take a look at my blog, featuring modding and programming related articles and more!
https://cookieplmonster.github.io/
